# Quiz 1 - Kaaviya's Krazy Kitchen 
I decided to make my website a combination of foods I really enjoy to eat. I decided to align the color scheme of my website with the cultural background surrounding the foods. 

Information architecture : 
my-restaurant
│
├── index.html
├── README.md
│
├── data/
│   └── menu.json
│
└── resources/
    ├── css/
    │   └── styles.css
    ├── js/
    │   └── app.js
    └── img/
        ├── Masala_Dosa.jpeg
        ├── Mutton_Biryani.jpg
        ├── Drunken_Noodles.jpeg
        └── Chicken_Shawarma.jpg
    